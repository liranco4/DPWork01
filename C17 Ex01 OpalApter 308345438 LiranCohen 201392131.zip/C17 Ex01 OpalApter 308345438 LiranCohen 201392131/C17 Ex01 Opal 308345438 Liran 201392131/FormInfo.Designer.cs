﻿namespace C17_Ex01_Opal_308345438_Liran_201392131
{
    partial class FormInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxPost = new System.Windows.Forms.TextBox();
            this.buttonPost = new System.Windows.Forms.Button();
            this.listBoxFetchFriends = new System.Windows.Forms.ListBox();
            this.buttonFetchFriends = new System.Windows.Forms.Button();
            this.pictureBoxFriendPic = new System.Windows.Forms.PictureBox();
            this.listBoxFetchLikedPages = new System.Windows.Forms.ListBox();
            this.buttonFetchLikedPages = new System.Windows.Forms.Button();
            this.pictureBoxLikedPage = new System.Windows.Forms.PictureBox();
            this.listBoxFetchPost = new System.Windows.Forms.ListBox();
            this.buttonFetchPost = new System.Windows.Forms.Button();
            this.listBoxFetchEvents = new System.Windows.Forms.ListBox();
            this.buttonFetchEvents = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFriendPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLikedPage)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxPost
            // 
            this.textBoxPost.Location = new System.Drawing.Point(97, 37);
            this.textBoxPost.Multiline = true;
            this.textBoxPost.Name = "textBoxPost";
            this.textBoxPost.Size = new System.Drawing.Size(823, 107);
            this.textBoxPost.TabIndex = 0;
            // 
            // buttonPost
            // 
            this.buttonPost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.buttonPost.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPost.Font = new System.Drawing.Font("Segoe UI", 13.8F);
            this.buttonPost.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonPost.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.buttonPost.Location = new System.Drawing.Point(947, 101);
            this.buttonPost.Name = "buttonPost";
            this.buttonPost.Size = new System.Drawing.Size(142, 43);
            this.buttonPost.TabIndex = 2;
            this.buttonPost.Text = "Post";
            this.buttonPost.UseVisualStyleBackColor = false;
            this.buttonPost.Click += new System.EventHandler(this.buttonPost_Click);
            // 
            // listBoxFetchFriends
            // 
            this.listBoxFetchFriends.FormattingEnabled = true;
            this.listBoxFetchFriends.ItemHeight = 16;
            this.listBoxFetchFriends.Location = new System.Drawing.Point(97, 311);
            this.listBoxFetchFriends.Name = "listBoxFetchFriends";
            this.listBoxFetchFriends.Size = new System.Drawing.Size(288, 404);
            this.listBoxFetchFriends.TabIndex = 3;
            this.listBoxFetchFriends.SelectedIndexChanged += new System.EventHandler(this.listBoxFetchFriends_SelectedIndexChanged);
            // 
            // buttonFetchFriends
            // 
            this.buttonFetchFriends.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.buttonFetchFriends.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFetchFriends.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFetchFriends.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonFetchFriends.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.buttonFetchFriends.Location = new System.Drawing.Point(97, 262);
            this.buttonFetchFriends.Name = "buttonFetchFriends";
            this.buttonFetchFriends.Size = new System.Drawing.Size(142, 43);
            this.buttonFetchFriends.TabIndex = 4;
            this.buttonFetchFriends.Text = "Friends";
            this.buttonFetchFriends.UseVisualStyleBackColor = false;
            this.buttonFetchFriends.Click += new System.EventHandler(this.buttonFetchFriends_Click);
            // 
            // pictureBoxFriendPic
            // 
            this.pictureBoxFriendPic.Location = new System.Drawing.Point(256, 194);
            this.pictureBoxFriendPic.Name = "pictureBoxFriendPic";
            this.pictureBoxFriendPic.Size = new System.Drawing.Size(129, 111);
            this.pictureBoxFriendPic.TabIndex = 6;
            this.pictureBoxFriendPic.TabStop = false;
            // 
            // listBoxFetchLikedPages
            // 
            this.listBoxFetchLikedPages.FormattingEnabled = true;
            this.listBoxFetchLikedPages.ItemHeight = 16;
            this.listBoxFetchLikedPages.Location = new System.Drawing.Point(479, 311);
            this.listBoxFetchLikedPages.Name = "listBoxFetchLikedPages";
            this.listBoxFetchLikedPages.Size = new System.Drawing.Size(288, 404);
            this.listBoxFetchLikedPages.TabIndex = 7;
            this.listBoxFetchLikedPages.SelectedIndexChanged += new System.EventHandler(this.listBoxFetchLikedPages_SelectedIndexChanged);
            // 
            // buttonFetchLikedPages
            // 
            this.buttonFetchLikedPages.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.buttonFetchLikedPages.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFetchLikedPages.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFetchLikedPages.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonFetchLikedPages.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.buttonFetchLikedPages.Location = new System.Drawing.Point(479, 262);
            this.buttonFetchLikedPages.Name = "buttonFetchLikedPages";
            this.buttonFetchLikedPages.Size = new System.Drawing.Size(142, 43);
            this.buttonFetchLikedPages.TabIndex = 8;
            this.buttonFetchLikedPages.Text = "liked pages";
            this.buttonFetchLikedPages.UseVisualStyleBackColor = false;
            this.buttonFetchLikedPages.Click += new System.EventHandler(this.buttonFetchLikedPages_Click);
            // 
            // pictureBoxLikedPage
            // 
            this.pictureBoxLikedPage.Location = new System.Drawing.Point(638, 194);
            this.pictureBoxLikedPage.Name = "pictureBoxLikedPage";
            this.pictureBoxLikedPage.Size = new System.Drawing.Size(129, 111);
            this.pictureBoxLikedPage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxLikedPage.TabIndex = 9;
            this.pictureBoxLikedPage.TabStop = false;
            // 
            // listBoxFetchPost
            // 
            this.listBoxFetchPost.FormattingEnabled = true;
            this.listBoxFetchPost.ItemHeight = 16;
            this.listBoxFetchPost.Location = new System.Drawing.Point(848, 311);
            this.listBoxFetchPost.Name = "listBoxFetchPost";
            this.listBoxFetchPost.Size = new System.Drawing.Size(361, 164);
            this.listBoxFetchPost.TabIndex = 10;
            // 
            // buttonFetchPost
            // 
            this.buttonFetchPost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.buttonFetchPost.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFetchPost.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFetchPost.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonFetchPost.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.buttonFetchPost.Location = new System.Drawing.Point(848, 262);
            this.buttonFetchPost.Name = "buttonFetchPost";
            this.buttonFetchPost.Size = new System.Drawing.Size(142, 43);
            this.buttonFetchPost.TabIndex = 11;
            this.buttonFetchPost.Text = "Fetch post";
            this.buttonFetchPost.UseVisualStyleBackColor = false;
            this.buttonFetchPost.Click += new System.EventHandler(this.buttonFetchPost_Click);
            // 
            // listBoxFetchEvents
            // 
            this.listBoxFetchEvents.FormattingEnabled = true;
            this.listBoxFetchEvents.ItemHeight = 16;
            this.listBoxFetchEvents.Location = new System.Drawing.Point(848, 551);
            this.listBoxFetchEvents.Name = "listBoxFetchEvents";
            this.listBoxFetchEvents.Size = new System.Drawing.Size(361, 164);
            this.listBoxFetchEvents.TabIndex = 12;
            // 
            // buttonFetchEvents
            // 
            this.buttonFetchEvents.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.buttonFetchEvents.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFetchEvents.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFetchEvents.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonFetchEvents.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.buttonFetchEvents.Location = new System.Drawing.Point(848, 502);
            this.buttonFetchEvents.Name = "buttonFetchEvents";
            this.buttonFetchEvents.Size = new System.Drawing.Size(142, 43);
            this.buttonFetchEvents.TabIndex = 13;
            this.buttonFetchEvents.Text = "Fetch Events";
            this.buttonFetchEvents.UseVisualStyleBackColor = false;
            this.buttonFetchEvents.Click += new System.EventHandler(this.buttonFetchEvents_Click);
            // 
            // FormInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::C17_Ex01_Opal_308345438_Liran_201392131.Properties.Resources._36427424_Mobile_apps_pattern_with_music_chat_gallery_speaking_bubble_email_magnifying_glass_shopping_search_n_Stock_Vector;
            this.ClientSize = new System.Drawing.Size(1235, 727);
            this.Controls.Add(this.buttonFetchEvents);
            this.Controls.Add(this.listBoxFetchEvents);
            this.Controls.Add(this.buttonFetchPost);
            this.Controls.Add(this.listBoxFetchPost);
            this.Controls.Add(this.pictureBoxLikedPage);
            this.Controls.Add(this.buttonFetchLikedPages);
            this.Controls.Add(this.listBoxFetchLikedPages);
            this.Controls.Add(this.pictureBoxFriendPic);
            this.Controls.Add(this.buttonFetchFriends);
            this.Controls.Add(this.listBoxFetchFriends);
            this.Controls.Add(this.buttonPost);
            this.Controls.Add(this.textBoxPost);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormInfo";
            this.Text = "FormInfo";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFriendPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLikedPage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxPost;
        private System.Windows.Forms.Button buttonPost;
        private System.Windows.Forms.ListBox listBoxFetchFriends;
        private System.Windows.Forms.Button buttonFetchFriends;
        private System.Windows.Forms.PictureBox pictureBoxFriendPic;
        private System.Windows.Forms.ListBox listBoxFetchLikedPages;
        private System.Windows.Forms.Button buttonFetchLikedPages;
        private System.Windows.Forms.PictureBox pictureBoxLikedPage;
        private System.Windows.Forms.ListBox listBoxFetchPost;
        private System.Windows.Forms.Button buttonFetchPost;
        private System.Windows.Forms.ListBox listBoxFetchEvents;
        private System.Windows.Forms.Button buttonFetchEvents;        
    }
}